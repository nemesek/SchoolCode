rm Elixir.MS.beam
rm Elixir.Star.beam

elixirc star.ex
elixirc master_slave.ex
